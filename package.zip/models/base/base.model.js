class BaseModel {
    get id() {
        return this._id;
    }
}

module.exports = BaseModel;
